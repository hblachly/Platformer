package platformer;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ViewNavigator {
	
	public static final String MAIN_MENU_SCENE = "MainMenuScene.fxml";
	public static final String LEVEL_SELECTOR_SCENE = "LevelSelectorScene.fxml";
	public static final String PROFILE_SEARCH_SCREEN = "SearchFunction.fxml";
	public static final String LEVEL_CREATOR_SCENE = "LevelCreatorScene.fxml";
	public static final String PLAYER_PROFILE_SCREEN = "PlayerProfileScene.fxml";
	// implement more of the fxml scenes for this to be complete
	
	
	public static Stage stage;
	

	public static void setStage(Stage stage) {
		ViewNavigator.stage = stage;
			}
		
	public static void loadScene(String title, String sceneFXML) {
		try {
			stage.setTitle("Main Menu");
			Scene scene = new Scene(FXMLLoader.load(ViewNavigator.class.getResource(sceneFXML)));
			stage.setScene(scene);
			stage.show();
			
		} catch (IOException e) {
			System.err.println("Error loading :" + sceneFXML + "\n" + e.getMessage());
			e.printStackTrace();
		}
	}
}
