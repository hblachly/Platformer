package platformer;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

public class SearchFunction implements Initializable {
	// get the text from the ProfileSearchTextBox 
	// take that text and search the ArrayList of users to find the specified user
	// if specified profile does not exist, show error code SearchProfilesError
	// else load that user's profile page and all their stats
	// will need to make a separate scene for a searched profile
	
	private static Controller controller = Controller.getInstance();

	@FXML
	private TextField profileSearchTextBox;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// ask
		
	}
	
	@FXML
	public void loadPlayerProfileScene() {
		ViewNavigator.loadScene("Search a Profile", ViewNavigator.PLAYER_PROFILE_SCREEN);
	}
	
	
/*	public void searchProfile(ActionEvent event) {
		String searchedProfile = profileSearchTextBox.getText();
		// check the entered text against the user database 
		for (int i = 0; i < observableList.size(); i++) {
			if (searchedProfile == )
		}
	}
	*/
}
