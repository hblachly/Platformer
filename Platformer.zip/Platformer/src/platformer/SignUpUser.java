package platformer;
/*

import java.sql.SQLException;
import java.util.Arrays;


public boolean isValidPassword(String password)
{
	// Valid password must contain (see regex below):
	// At least one lower case letter
	// At least one digit
	// At least one special character (@, #, $, %, !)
	// At least one upper case letter
	// At least 8 characters long, but no more than 16
	return password.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\\\|,.<>\\/?]).{8,16}$");
}

public boolean isValidEmail(String email)
{
	return email.matches(
			"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
}

public String signUpUser(String name, String email, String password)
{
    // Check email to see if valid
    if (!isValidEmail(email))
        return "Email address not valid. Please try different address.";

    // Check to see if email is already used
    // Loop through all users list
    for (User u : theOne.mAllUsersList)
        if (email.equalsIgnoreCase(u.getEmail()))
            return "Email address already used. Please sign in or use different address.";


    // Check password to see if valid
//    if(!isValidPassword(password))
//        return "Password must be at least 8 characters, including 1 uppercase letter, 1 number, and 1 symbol.";

    // Made it through all the checks, create the new user in the databse
    String[] values = {name, email, "user", password};
    // Insert into the database
    try
    {
        // Store the new id
        int id = theOne.mUserDB.createRecord(
                Arrays.copyOfRange(USER_FIELD_NAMES, 1, USER_FIELD_NAMES.length), values);
        // Save the new user as the current user
        theOne.mCurrentUser = new User(id, name, email, "user");
        // add the new user to the observable list
        theOne.mAllUsersList.add(theOne.mCurrentUser);
    }
    catch (SQLException e)
    {
        // TODO Auto-generated catch block
        e.printStackTrace();
        return "Error creating user, please try again.";
    }


	return "SUCCESS";
}
*/