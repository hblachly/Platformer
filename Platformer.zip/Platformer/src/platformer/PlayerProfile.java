package platformer;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class PlayerProfile implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	// Search current user data for number of levels completed,
	// coins collected, number of deaths, and position on the leaderboard
	// this will be a relationship database that will need implementation
	// holds all that ^^ information plus possibly more.
	
	
	@FXML
	public void loadMainMenu() {
		ViewNavigator.loadScene("Main Menu", ViewNavigator.MAIN_MENU_SCENE);
	}
	
	@FXML
	public void loadProfileSearch() {
		ViewNavigator.loadScene("Search a Profile", ViewNavigator.PROFILE_SEARCH_SCREEN);
	}
	
	@FXML
	public void loadLevelSelector() {
		ViewNavigator.loadScene("Select a Level", ViewNavigator.LEVEL_SELECTOR_SCENE);
	}
	
}
