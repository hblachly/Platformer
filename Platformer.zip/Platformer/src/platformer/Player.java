package platformer;

public class Player {

}
