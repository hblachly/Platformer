package platformer;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

	// load the ArrayList of available levels 
	// show the scene
	// if a level has been completed by the current user
	// load a check box next to that level.
	// maybe load number of coins collected on that level

public class LevelSelector implements Initializable {
	
	private static Controller controller = Controller.getInstance();
	
	@FXML
	private ListView<Level> levelsLV;
	
	@FXML
	private Label levelsLabel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		levelsLV.setItems(controller.getAvailableLevels());
		
	}

	public void loadLevelSelector() {
		ViewNavigator.loadScene("Level Selector", ViewNavigator.LEVEL_SELECTOR_SCENE)
	}
	
	
}
