package platformer;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class UserCreateYourOwnLevel implements Initializable{

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML
	public void StartLevelCreator() {
		ViewNavigator.loadScene("Level Creator", ViewNavigator.LEVEL_CREATOR_SCENE);
	}
	
	@FXML
	public void loadMainMenu() {
		ViewNavigator.loadScene("Main Menu", ViewNavigator.MAIN_MENU_SCENE);
	}
}
